import { Component } from '@angular/core';

@Component({
  selector: 'app-day-review',
  standalone: true,
  template: `
    <div class="container">
      <h1>Day Review</h1>
      <p>Tell us about your day 🌟</p>
    </div>
  `
})
export class DayReviewComponent {}