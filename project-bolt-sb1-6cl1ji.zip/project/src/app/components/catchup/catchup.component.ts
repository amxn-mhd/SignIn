import { Component } from '@angular/core';

@Component({
  selector: 'app-catchup',
  standalone: true,
  template: `
    <div class="container">
      <h1>Important Tasks</h1>
      <p>Catch up with important things 🤔</p>
    </div>
  `
})
export class CatchupComponent {}