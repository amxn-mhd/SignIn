import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="main-content">
      <div class="mood-analyzer">
        <h2>Mood Analyzer</h2>
        <div class="mood-list">
          <div class="mood-item" *ngFor="let mood of moodData">
            <span class="star-icon">⭐</span>
            <div>
              <div>{{mood.day}}</div>
              <div>Score: {{mood.score}}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="interaction-panel">
        <a routerLink="/sleep" class="interaction-box">
          How was your sleep today? 💫
        </a>
        <a routerLink="/catchup" class="interaction-box">
          Is there something important to catch up with? 🤔
        </a>
        <a routerLink="/day-review" class="interaction-box">
          Tell me about your day 🌟
        </a>
        <a routerLink="/emergency" class="emergency-button">
          Tap me to get Emergency Services 🚨
        </a>
        <a routerLink="/incident" class="report-incident">
          Report an Incident ⚡⚡
        </a>
      </div>

      <div class="reminders-section">
        <h2>Reminders</h2>
        <div class="reminders-grid">
          <div class="reminder-item" *ngFor="let reminder of reminders">
            <input type="checkbox" [id]="reminder.id">
            <label [for]="reminder.id">
              {{reminder.task}}
              <div>Time: {{reminder.time}}</div>
            </label>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent {
  moodData = [
    { day: 'Today', score: 85 },
    { day: 'Yesterday', score: 90 },
    { day: '05/10/24', score: 80 },
    { day: '04/10/24', score: 85 },
    { day: '03/10/24', score: 75 }
  ];

  reminders = [
    { id: 'breakfast', task: 'Have Breakfast', time: '08:00 AM' },
    { id: 'card', task: 'Swipe ID Card', time: '09:00 AM' },
    { id: 'snack', task: 'Have Snack', time: '11:00 AM' },
    { id: 'boss', task: 'Call Boss', time: '11:30 AM' },
    { id: 'water', task: 'Drink Water', time: '12:00 PM' },
    { id: 'lunch', task: 'Have Lunch', time: '02:00 PM' },
    { id: 'task', task: "Complete Yesterday's Task", time: '03:00 PM' },
    { id: 'dinner', task: 'Order food for Dinner', time: '07:00 PM' }
  ];
}