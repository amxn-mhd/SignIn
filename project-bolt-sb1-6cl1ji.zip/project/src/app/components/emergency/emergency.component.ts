import { Component } from '@angular/core';

@Component({
  selector: 'app-emergency',
  standalone: true,
  template: `
    <div class="container">
      <h1>Emergency Services</h1>
      <p>Emergency contact numbers and services 🚨</p>
    </div>
  `
})
export class EmergencyComponent {}