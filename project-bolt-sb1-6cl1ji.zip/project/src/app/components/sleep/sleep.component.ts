import { Component } from '@angular/core';

@Component({
  selector: 'app-sleep',
  standalone: true,
  template: `
    <div class="container">
      <h1>Sleep Tracker</h1>
      <p>How was your sleep today? 💫</p>
    </div>
  `
})
export class SleepComponent {}