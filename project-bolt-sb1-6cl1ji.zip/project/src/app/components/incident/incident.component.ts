import { Component } from '@angular/core';

@Component({
  selector: 'app-incident',
  standalone: true,
  template: `
    <div class="container">
      <h1>Report Incident</h1>
      <p>Report an incident or issue ⚡⚡</p>
    </div>
  `
})
export class IncidentComponent {}