import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SleepComponent } from './components/sleep/sleep.component';
import { CatchupComponent } from './components/catchup/catchup.component';
import { DayReviewComponent } from './components/day-review/day-review.component';
import { EmergencyComponent } from './components/emergency/emergency.component';
import { IncidentComponent } from './components/incident/incident.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'sleep', component: SleepComponent },
  { path: 'catchup', component: CatchupComponent },
  { path: 'day-review', component: DayReviewComponent },
  { path: 'emergency', component: EmergencyComponent },
  { path: 'incident', component: IncidentComponent },
  { path: '**', redirectTo: '' }
];