import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, CommonModule],
  template: `
    <div class="container">
      <header class="header">
        <div class="logo">CC</div>
        <div class="header-buttons">
          <button class="btn btn-sos">SOS</button>
          <button class="btn btn-logout">LogOut</button>
        </div>
      </header>

      <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent {}